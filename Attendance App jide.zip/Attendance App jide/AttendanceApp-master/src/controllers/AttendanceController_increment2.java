package controllers;


import helpers.InputHelper;
import java.util.Comparator;
import model.Swipe;
import model.VisitorSwipe;
import repositories.Repository;

/**
 *
 * @author STANLEY
 */
public class AttendanceController_increment2 {
  private final Repository repository;
  
  public AttendanceController_increment2() {
  InputHelper inputHelper = new InputHelper();
  char c = inputHelper.readCharacter ("Would you like to load already existing swipes (Y/N)?");
    if (c == 'Y' || c == 'y') {
            String fileName = inputHelper.readString("Enter filename");
            this.repository = new Repository(fileName);
        } else {
            this.repository = new Repository();
        }
    listSwipes();
}
/**
     *
     */
    public void run() {
        boolean finished = false;

        do {
            char choice = displayAttendanceMenu();
            switch (choice) {
                case 'A':
                    addSwipe();
                    break;
                case 'B':
                    listSwipes();
                    break;
                case 'C':
                    listSwipesInReverseDateTimeOrder();
                    break;
                case 'D':
                    listSwipesWhichMatchCardId();
                    break;
                case 'Q':
                    finished = true;
            }
        } while (!finished);

        InputHelper helper = new InputHelper();
        if (repository.getItems().getItems().size() > 0) {
            char choice = helper.readCharacter("Would you like to save the available swipes(Y/N) ? ");
            if (choice == 'Y' || choice == 'y') {
                String filename = helper.readString("Enter any filename your prefer? ");
                if (filename == null || filename == "")
                    System.out.println("Your file could not be saved, you did not provide a valid filename");
                else repository.store(filename);
            }
        }
    }

    private char displayAttendanceMenu() {
        InputHelper inputHelper = new InputHelper();
        System.out.print("\nA. Add Swipe");
        System.out.print("\tB. List Swipes");
        System.out.print("\tC. List Swipes In Date Time Order");
        System.out.print("\tD. List Swipes Which Match Card Id");
        System.out.print("\tQ. Quit\n");
        return inputHelper.readCharacter("Enter choice", "ABCDQ");
    }

    private void addSwipe() {
        System.out.format("\033[31m%s\033[0m%n", "Add Swipe");
        System.out.format("\033[31m%s\033[0m%n", "===============");
        InputHelper inputHelper = new InputHelper();
        Swipe swipe;
        boolean valid = false;
        do {
            char choice = inputHelper.readCharacter("A. Visitor \t B. Not A Visitor ");
            if (choice == 'A' || choice == 'a') {
                valid = true;
                repository.add(collectSwipeInput(true));
            } else if (choice == 'B' || choice == 'b') {
                valid = true;
                repository.add(collectSwipeInput(false));
            }

        } while (!valid);

    }

    private Swipe collectSwipeInput(boolean isVisitor) {
        InputHelper helper = new InputHelper();
        String cardId, room, name, company = "";
        cardId = helper.readString("Card Id? ");
        room = helper.readString("Room Number? ");
        if (isVisitor) {
            VisitorSwipe swipe;
            name = helper.readString("Your name? ");
            company = helper.readString("Your company Name? ");
            swipe = new VisitorSwipe(cardId, room);
            swipe.setVisitorCompany(company);
            swipe.setVisitorName(name);
            return swipe;
        } else
            return new Swipe(cardId, room);
    }

    private void listSwipes() {
        System.out.println(repository.toString());
    }

    private void listSwipesInReverseDateTimeOrder() {
        System.out.println(repository.reverseToString());
    }

    private void listSwipesWhichMatchCardId() {
        InputHelper helper = new InputHelper();
        String id = helper.readString("Enter card Id");
      
        System.out.format("\033[31m%s\033[0m%n", "Swipes By Card ");
        System.out.format("\033[31m%s\033[0m%n", "=================");
        
    }
}