package model;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Objects;

/**
 * @author mga
 */
public class Swipe {

    /**
     *
     */
    protected final int id;

    /**
     *
     */
    protected String cardId;

    /**
     *
     */
    protected String room;

    /**
     *
     */
    protected final Calendar swipeDateTime;

    private static int lastSwipeIdUsed = 0;
    static final char EOLN = '\n';
    static final String QUOTE = "\"";

    /**
     *
     */
    public Swipe() {
        this.id = ++lastSwipeIdUsed;
        this.cardId = "Unknown";
        this.room = "Unknown";
        this.swipeDateTime = getNow();
    }

    /**
     * @param cardId
     * @param room
     */
    public Swipe(String cardId, String room) {
        this.id = ++lastSwipeIdUsed;
        this.cardId = cardId;
        this.room = room;
        this.swipeDateTime = getNow();
    }


    /**
     * @param swipeId
     * @param cardId
     * @param room
     * @param swipeDateTime
     */
    public Swipe(int swipeId, String cardId, String room, Calendar swipeDateTime) {
        this.id = swipeId;
        this.cardId = cardId;
        this.room = room;
        this.swipeDateTime = swipeDateTime;
        if (swipeId > Swipe.lastSwipeIdUsed)
            Swipe.lastSwipeIdUsed = swipeId;
    }


    private Calendar getNow() {
        Calendar now = Calendar.getInstance();
        return now;
    }

    public Calendar getSwipeDateTime() {
        return swipeDateTime;
    }


    /**
     * @return the id
     */
    public int getId() {
        return this.id;
    }

    // Methods required: getters, setters, hashCode, equals, compareTo, comparator


    public String getCardId() {
        return cardId;
    }

    public void setCardId(String cardId) {
        this.cardId = cardId;
    }

    public String getRoom() {
        return room;
    }

    public void setRoom(String room) {
        this.room = room;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Swipe swipe = (Swipe) o;
        return getCardId().equals(swipe.getCardId()) &&
                getRoom().equals(swipe.getRoom());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getCardId(), getRoom());
    }


    /**
     * @param calendar
     * @return
     */

    public static String formatSwipeDateTime(Calendar calendar) {
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Calendar now = Calendar.getInstance();
        return dateFormat.format(calendar.getTime());
    }

    /**
     * Used to convert string back to calendar object when reading collection from file
     *
     * @param dateString
     * @return
     * @throws ParseException
     */
    public static Calendar formatSwipeDateTime(String dateString) throws ParseException {
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = dateFormat.parse(dateString);
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return calendar;
    }

    /**
     * @return
     */
    @Override
    public String toString() {
        return "\nSwipe Id: " + this.id + " - Card Id: " + this.cardId +
                " - Room: " + this.room + " - Swiped: " + formatSwipeDateTime(this.swipeDateTime);
    }

    /**
     * @param delimiter
     * @return
     */
    public String toString(char delimiter) {
        final String QUOTE = "\"";
        return Integer.toString(this.id) + delimiter + QUOTE + this.cardId + QUOTE +
                delimiter + QUOTE + this.room + QUOTE + delimiter + QUOTE + formatSwipeDateTime(this.swipeDateTime) + QUOTE + EOLN;
    }

    /**
     * Compares two swipes an integer
     * less than 0 if swipe1 was earlier than swipe 2
     * equal to 0 time of two swipes are the same
     * more than 0 if swipe 2 was earlier than swipe 1
     *
     * @param swipe1
     * @param swipe2
     * @return
     */
    public static int swipeDateTimeComparator(Swipe swipe1, Swipe swipe2) {
        return swipe1.compareTo(swipe2);
    }

    public int compareTo(Swipe swipe) {
        return this.swipeDateTime.compareTo(swipe.getSwipeDateTime());
    }

//    @Override
//    public int compareTo(Object o) {
//        return this.swipeDateTime.compareTo(((Swipe) o).getSwipeDateTime());
//    }
}
